# WIPP Semantic Segmentation > 2023-03-13 3:51pm
https://universe.roboflow.com/semantic-segmentation/wipp-semantic-segmentation

Provided by a Roboflow user
License: CC BY 4.0

